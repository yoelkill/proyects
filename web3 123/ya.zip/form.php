<!doctype html>
<html lang="es">
	<head>
		<title>Registrar</title>
			<meta charset="utf-8"/>
			<link rel="stylesheet" href="css/estilo.css">
			<link rel="stylesheet" href="css/normalize.css">

			<meta name="viewport" content="width=device-width, maximun-scale=1">

			<script src='https://www.google.com/recaptcha/api.js?hl=es'></script>
	</head>
	<body>

	<script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>
	
	
	<footer id="contacto" class="Footer">

		<footer class="Footer-form2">
		
		</footer>


		<h1 class="Footer-title1">FORMULARIO DE REGISTRO </h1>

		<footer class="Footer-form">
			<h2 class="Footer-title">REGISTRAR </h2>
			<p class="Footer-desciption">Ingrese usuario y contraseña</p>
		<form action="insertar.php" method="post" name="form">

				<label>Usuario</label>
				<input class="Footer-formInput" type="text" name="nombre" placeholder="Nombre" name="asunto"/>
			
				<label>Contraseña</label>
				<input class="Footer-formInput" type="password" name="pass" placeholder="Contraseña">
			
				<input class="Footer-button" type="submit" value="Insertar datos"><br/><br/>

				</div>
				</div>


				<footer class="Footer-form1">

				<a class="Profile-link" class="Footer-button" href="index.php">Regresar</a>
			
				<center>
					<div class="g-recaptcha"  data-sitekey="6LeFKhITAAAAADihn7mHoPmetOJ9oIKtcMEbZZWV">
					</div>
					</center>
				</footer>
			</footer>
		
		</form>
			<footer class="Footer-form2">
			<FORM action="select.php" method="post" name="form">
			<p>BUSCAR</p>
			<input class="Footer-formInput" type="text" name="nombre" placeholder="Nombre"/><br/><br/>
			<input class="Footer-button" type="submit" value="Seleccionar"><br/><br/>
			</FORM>
			</footer>
		</footer>	
	</center>	
	</body>
</html>